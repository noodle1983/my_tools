#!/bin/bash

bf2_pid=`ps -ef|grep [b]fserver_2.lua |awk -e '{print $2;}'`
if [ "$bf2_pid" != "" ]
then
        echo "bf2 already started with pid:${bf2_pid}"
else
        cd inc_rel/bfserver/
	./bfserverbf_app -c bfserver_2.lua
        cd -
        sleep 1
	bf2_pid=`ps -ef|grep [b]fserver_2.lua |awk -e '{print $2;}'`
        if [ "$bf2_pid" == "" ]
        then
                echo "bf2 can't be started."
                exit -1
        else
                echo "bf2 started with pid:${bf2_pid}."
        fi
fi


