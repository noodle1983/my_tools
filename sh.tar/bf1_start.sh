#!/bin/bash

bf1_pid=`ps -ef|grep [b]fserver_1.lua |awk -e '{print $2;}'`
if [ "$bf1_pid" != "" ]
then
        echo "bf1 already started with pid:${bf1_pid}"
else
        cd inc_rel/bfserver/
	./bfserverbf_app -c bfserver_1.lua
        cd -
        sleep 1
	bf1_pid=`ps -ef|grep [b]fserver_1.lua |awk -e '{print $2;}'`
        if [ "$bf1_pid" == "" ]
        then
                echo "bf1 can't be started."
                exit -1
        else
                echo "bf1 started with pid:${bf1_pid}."
        fi
fi


