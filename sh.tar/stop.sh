#!/bin/bash
./login_stop.sh
./bf0_stop.sh
./bf1_stop.sh
./bf2_stop.sh
./20001_stop.sh
./20035_stop.sh
