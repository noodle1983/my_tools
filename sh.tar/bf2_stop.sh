#!/bin/bash

bf2_pid=`ps -ef|grep [b]fserver_2.lua |awk -e '{print $2;}'`
kill -10 ${bf2_pid}
while [ "$bf2_pid" != "" ]
do
        echo "wait bf2 to stop, pid:${bf2_pid}"
        sleep 1
	bf2_pid=`ps -ef|grep [b]fserver_2.lua |awk -e '{print $2;}'`
done
