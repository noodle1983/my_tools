#!/bin/bash

bf1_pid=`ps -ef|grep [b]fserver_1.lua |awk -e '{print $2;}'`
kill -10 ${bf1_pid}
while [ "$bf1_pid" != "" ]
do
        echo "wait bf1 to stop, pid:${bf1_pid}"
        sleep 1
	bf1_pid=`ps -ef|grep [b]fserver_1.lua |awk -e '{print $2;}'`
done
