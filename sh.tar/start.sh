#!/bin/bash
./login_start.sh
./bf0_start.sh
./bf1_start.sh
./bf2_start.sh
./20001_start.sh
./20035_start.sh
