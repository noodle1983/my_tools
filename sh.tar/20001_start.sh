#!/bin/bash

db_pid=`ps -ef|grep [d]bserver_20001.lua |awk -e '{print $2;}'`
if [ "$db_pid" != "" ]
then
        echo "db 20001 already started with pid:${db_pid}"
else
        cd inc_rel/dbserver/
        ./dbserverdb_app -c dbserver_20001.lua
        cd -
        sleep 1
        db_pid=`ps -ef|grep [d]bserver_20001.lua |awk -e '{print $2;}'`
        if [ "$db_pid" == "" ]
        then
                echo "db 20001 can't be started."
                exit -1
        else
                echo "db 20001 started with pid:${db_pid}."
        fi
fi


game_pid=`ps -ef|grep [g]ameserver_20001.lua |awk -e '{print $2;}'`
if [ "$game_pid" != "" ]
then
        echo "game 20001 already started with pid:${game_pid}"
else
        cd inc_rel/gameserver/
        ./gameservergame_app -c gameserver_20001.lua
        cd -
        sleep 1
        game_pid=`ps -ef|grep [g]ameserver_20001.lua |awk -e '{print $2;}'`
        if [ "$game_pid" == "" ]
        then
                echo "game 20001 can't be started."
                exit -1
        else
                echo "game 20001 started with pid:${game_pid}."
        fi
fi

