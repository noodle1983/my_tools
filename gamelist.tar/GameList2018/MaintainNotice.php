<?php
$file_name = "maintain_cfg.ini";
$req = $_GET;

$data = array();
$data['title'] = urldecode($req['title']);
$data['url'] = urldecode($req['url']);
$data['startTime'] = intval($req['startTime']);
$data['endTime'] = intval($req['endTime']);
$req_sign =  $req['sign'];

$signData = $data;
$signKey = ")%@*(#%IJDGkkdgn12";
ksort($signData);
$httpData = http_build_query($signData);//注意，这里会对value进行urlencode
$httpDataAppend = $httpData.$signKey;
$sign = md5($httpDataAppend);

$resp = array();
if ($sign != $req_sign)
{
    $resp['code'] = -1;
    echo json_encode($resp);
    return;
}

$text = json_encode($data);
if ($fp = fopen($file_name, "w")) {
    if (fwrite($fp, $text)) {
        fclose($fp);
        $resp['code'] = 1;
        echo json_encode($resp);
    } else {
        fclose($fp);
        $resp['code'] = -1;
        echo json_encode($resp);
    } 
} 
